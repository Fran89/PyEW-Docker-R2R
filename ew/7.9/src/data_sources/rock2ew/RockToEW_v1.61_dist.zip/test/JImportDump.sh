#!/bin/sh

java -jar JImportDump.jar $*
